 @if (isset($data))

        <div class="card-body">
            <div class="users-list-filter">
                {{ $data->id }}
            </div>
        </div>


@endif
